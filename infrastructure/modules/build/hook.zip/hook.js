'use strict';

const { execSync } = require('child_process')
const fs = require('fs')

exports.handler = async (event, context) => {
    const response = {
        headers: {
            'Content-Type': 'text/html; charset=utf-8',
        },
        isBase64Encoded: false,
        statusCode: 200,
        statusDescription: '200 OK',
        body: ''
    };

    var body = JSON.parse(event.body);

    if (body.test !== undefined) {
        return response;
    }

    var ssh_url = body.repository.links.clone.filter(function (obj) {
        return obj.name === 'ssh';
    })[0].href;
    var branch = body.changes[0].ref.displayId;

    if (branch !== process.env.BRANCH) {
        return response;
    }

    execSync('rm -rf /tmp/*', { encoding: 'utf8', stdio: 'inherit' });

    fs.writeFileSync('/tmp/known_hosts', process.env.KNOWN_HOSTS)

    const AWS = require("aws-sdk");
    const ssm = new AWS.SSM();

    // reading a secret value from the SSM Parameters Store
    const gitKey = await ssm.getParameter({
        Name: process.env.GIT_KEY_PARAMETER,
        WithDecryption: true,
    }).promise();

    fs.writeFileSync('/tmp/id_rsa', gitKey.Parameter.Value);
    execSync('chmod 400 /tmp/id_rsa', { encoding: 'utf8', stdio: 'inherit' });

    process.env.GIT_SSH_COMMAND = 'ssh -o UserKnownHostsFile=/tmp/known_hosts -i /tmp/id_rsa'

    execSync('git clone -b ' + branch + ' ' + ssh_url + ' /tmp/source', { encoding: 'utf8', stdio: 'inherit' });

    execSync('cd /tmp/source && zip -r /tmp/source.zip * .[^.]*');

    const s3 = new AWS.S3();

    await s3.putObject({
        Bucket: process.env.SOURCE_BUCKET,
        Key: 'source.zip',
        Body: fs.createReadStream('/tmp/source.zip')
    }).promise();

    const codeBuild = new AWS.CodeBuild();

    await codeBuild.startBuild({
        projectName: process.env.BUILD_PROJECT
    }).promise();

    return response;
};
